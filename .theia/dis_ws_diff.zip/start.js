"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("theme");
var routes_1 = __importDefault(require("routes"));
routes_1.default.push('/btb');
//# sourceMappingURL=start.js.map