"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    cancel: 'Stornieren',
    copy: 'Kopieren',
    done: 'Übersetzung',
    copyURL: 'URL Kopieren',
    cut: 'Schneiden',
    no: 'Nein',
    ok: 'Okay',
    paste: 'Einfügen',
    selectAll: 'Alle Auswählen',
    untitled: 'Ohne Adelsrang',
    yes: 'Ja',
    sureToDelete: 'Sind Sie sicher zu löschen?',
    networkError: 'Es hat einen Netzwerkfehler, bitte versuchen Sie es später noch einmal',
    applicationError: 'Es ist ein nicht behandelter Anwendungsfehler gewesen, informieren Sie bitte Entwickler'
};
//# sourceMappingURL=de.js.map