"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    cancel: 'Keskeytä',
    copy: 'Kopioi',
    done: 'Käännös ',
    copyURL: 'Kopioi URL',
    cut: 'Leikkaa',
    no: 'Ei',
    ok: 'OK',
    paste: 'Liitä',
    selectAll: 'Valitse Kaikki',
    untitled: 'Nimetön',
    yes: 'Kyllä',
    sureToDelete: 'Haluatko varmasti poistaa?',
    networkError: 'Tapahtui verkkovirhe. Yritä myöhemmin uudelleen',
    applicationError: 'Tapahtui käsittelemätön virhe. Ilmoita sovelluksen kehittäjille'
};
//# sourceMappingURL=fi.js.map