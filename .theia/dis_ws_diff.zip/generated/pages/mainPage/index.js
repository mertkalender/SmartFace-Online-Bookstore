"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var gridview_1 = __importDefault(require("@smartface/native/ui/gridview"));
var listview_1 = __importDefault(require("@smartface/native/ui/listview"));
var layoutmanager_1 = __importDefault(require("@smartface/native/ui/layoutmanager"));
var addChild_1 = __importDefault(require("@smartface/styling-context/lib/action/addChild"));
var GviBook_1 = __importDefault(require("components/GviBook"));
var LviBook_1 = __importDefault(require("components/LviBook"));
var $MainPage = /** @class */ (function (_super) {
    __extends($MainPage, _super);
    function $MainPage(props) {
        var _this = _super.call(this, Object.assign({ orientation: page_1.default.Orientation.PORTRAIT }, props)) || this;
        _this._children = {};
        _this.ios && (_this.ios.safeAreaLayoutMode = true);
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $Profile(), 'profile');
        _this.addChildByName(new $PopularBooksView(), 'popularBooksView');
        _this.addChildByName(new $NewestBooksView(), 'newestBooksView');
        _this.profile = _this.children.profile;
        _this.profileInfo = _this.children.profile.children.profileInfo;
        _this.profilePhoto = _this.children.profile.children.profileInfo.children.profilePhoto;
        _this.welcomeName = _this.children.profile.children.profileInfo.children.welcomeName;
        _this.searchButton = _this.children.profile.children.profileInfo.children.searchButton;
        _this.popularBooksView = _this.children.popularBooksView;
        _this.popularBooks = _this.children.popularBooksView.children.popularBooks;
        _this.popularBooksList = _this.children.popularBooksView.children.popularBooksList;
        _this.newestBooksView = _this.children.newestBooksView;
        _this.newestBooks = _this.children.newestBooksView.children.newestBooks;
        _this.newestBooksList = _this.children.newestBooksView.children.newestBooksList;
        _this.applyTestIDs('_MainPage');
        return _this;
    }
    Object.defineProperty($MainPage.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $MainPage.prototype.getName = function () {
        return 'MainPage';
    };
    $MainPage.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'Page1';
    };
    $MainPage.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $MainPage.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $MainPage.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $MainPage.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $MainPage.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $MainPage.$$styleContext = {
        classNames: '.sf-page #page1',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar #statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar #header',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $MainPage;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $MainPage;
var $Profile = /** @class */ (function (_super) {
    __extends($Profile, _super);
    function $Profile(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $Profile$$ProfileInfo(), 'profileInfo');
        return _this;
    }
    Object.defineProperty($Profile.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $Profile.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $Profile.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Profile.$$styleContext = {
        classNames: '.sf-flexLayout #search',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $Profile;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $Profile$$ProfileInfo = /** @class */ (function (_super) {
    __extends($Profile$$ProfileInfo, _super);
    function $Profile$$ProfileInfo(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $Profile$$ProfileInfo$$ProfilePhoto(), 'profilePhoto');
        _this.addChildByName(new $Profile$$ProfileInfo$$WelcomeName(), 'welcomeName');
        _this.addChildByName(new $Profile$$ProfileInfo$$SearchButton(), 'searchButton');
        return _this;
    }
    Object.defineProperty($Profile$$ProfileInfo.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $Profile$$ProfileInfo.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $Profile$$ProfileInfo.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Profile$$ProfileInfo.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-profileInfo',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $Profile$$ProfileInfo;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $Profile$$ProfileInfo$$ProfilePhoto = /** @class */ (function (_super) {
    __extends($Profile$$ProfileInfo$$ProfilePhoto, _super);
    function $Profile$$ProfileInfo$$ProfilePhoto(props) {
        return _super.call(this, props) || this;
    }
    $Profile$$ProfileInfo$$ProfilePhoto.$$styleContext = {
        classNames: '.sf-imageView #mainPage-profilePhoto',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $Profile$$ProfileInfo$$ProfilePhoto;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $Profile$$ProfileInfo$$WelcomeName = /** @class */ (function (_super) {
    __extends($Profile$$ProfileInfo$$WelcomeName, _super);
    function $Profile$$ProfileInfo$$WelcomeName(props) {
        return _super.call(this, { maxLines: 1, text: 'Hi, Dustin!' }) || this;
    }
    $Profile$$ProfileInfo$$WelcomeName.$$styleContext = {
        classNames: '.sf-label #mainPage-profileName',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $Profile$$ProfileInfo$$WelcomeName;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $Profile$$ProfileInfo$$SearchButton = /** @class */ (function (_super) {
    __extends($Profile$$ProfileInfo$$SearchButton, _super);
    function $Profile$$ProfileInfo$$SearchButton(props) {
        return _super.call(this, { text: '' }) || this;
    }
    $Profile$$ProfileInfo$$SearchButton.$$styleContext = {
        classNames: '.sf-label #mainPage-searchButton',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $Profile$$ProfileInfo$$SearchButton;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $PopularBooksView = /** @class */ (function (_super) {
    __extends($PopularBooksView, _super);
    function $PopularBooksView(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $PopularBooksView$$PopularBooks(), 'popularBooks');
        _this.addChildByName(new $PopularBooksView$$PopularBooksList(), 'popularBooksList');
        return _this;
    }
    Object.defineProperty($PopularBooksView.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $PopularBooksView.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $PopularBooksView.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $PopularBooksView.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-list',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $PopularBooksView;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $PopularBooksView$$PopularBooks = /** @class */ (function (_super) {
    __extends($PopularBooksView$$PopularBooks, _super);
    function $PopularBooksView$$PopularBooks(props) {
        return _super.call(this, { text: 'Popular Books' }) || this;
    }
    $PopularBooksView$$PopularBooks.$$styleContext = {
        classNames: '.sf-label #mainPage-headers',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $PopularBooksView$$PopularBooks;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $PopularBooksView$$PopularBooksList = /** @class */ (function (_super) {
    __extends($PopularBooksView$$PopularBooksList, _super);
    function $PopularBooksView$$PopularBooksList(props) {
        var _this = _super.call(this, __assign({ layoutManager: new layoutmanager_1.default({ scrollDirection: layoutmanager_1.default.ScrollDirection.HORIZONTAL, spanCount: 1, onItemLength: function () { return 227; } }) }, { itemLength: 227 })) || this;
        _this.itemIndex = 0;
        _this.onItemCreate = function () {
            var item = new $PopularBooksView$$PopularBooksList$$GviBook();
            _this.dispatch((0, addChild_1.default)("item".concat(++_this.itemIndex), item));
            return item;
        };
        return _this;
    }
    $PopularBooksView$$PopularBooksList.$$styleContext = {
        classNames: '.sf-gridView #mainPage-bookList',
        defaultClassNames: '.default_common .default_gridView',
        userProps: { props: { layoutManager: { scrollDirection: 'HORIZONTAL', spanCount: 1 } } }
    };
    return $PopularBooksView$$PopularBooksList;
}((0, styling_context_1.styleableComponentMixin)(gridview_1.default)));
var $PopularBooksView$$PopularBooksList$$GviBook = /** @class */ (function (_super) {
    __extends($PopularBooksView$$PopularBooksList$$GviBook, _super);
    function $PopularBooksView$$PopularBooksList$$GviBook(props) {
        return _super.call(this, props) || this;
    }
    $PopularBooksView$$PopularBooksList$$GviBook.$$styleContext = {
        classNames: '.sf-gridViewItem .simple-gridviewItem #mainPage-gviBook',
        defaultClassNames: '.default_common .default_gridViewItem',
        userProps: {}
    };
    return $PopularBooksView$$PopularBooksList$$GviBook;
}(GviBook_1.default));
var $NewestBooksView = /** @class */ (function (_super) {
    __extends($NewestBooksView, _super);
    function $NewestBooksView(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $NewestBooksView$$NewestBooks(), 'newestBooks');
        _this.addChildByName(new $NewestBooksView$$NewestBooksList(), 'newestBooksList');
        return _this;
    }
    Object.defineProperty($NewestBooksView.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $NewestBooksView.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $NewestBooksView.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $NewestBooksView.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-list',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $NewestBooksView;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $NewestBooksView$$NewestBooks = /** @class */ (function (_super) {
    __extends($NewestBooksView$$NewestBooks, _super);
    function $NewestBooksView$$NewestBooks(props) {
        return _super.call(this, { text: 'Newest' }) || this;
    }
    $NewestBooksView$$NewestBooks.$$styleContext = {
        classNames: '.sf-label #mainPage-headers',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $NewestBooksView$$NewestBooks;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $NewestBooksView$$NewestBooksList = /** @class */ (function (_super) {
    __extends($NewestBooksView$$NewestBooksList, _super);
    function $NewestBooksView$$NewestBooksList(props) {
        var _this = _super.call(this, { rowHeight: 250 }) || this;
        _this.itemIndex = 0;
        _this.onRowCreate = function () {
            var item = new $NewestBooksView$$NewestBooksList$$LviBook();
            _this.dispatch((0, addChild_1.default)("item".concat(++_this.itemIndex), item));
            return item;
        };
        return _this;
    }
    $NewestBooksView$$NewestBooksList.$$styleContext = {
        classNames: '.sf-listView #mainPage-bookList',
        defaultClassNames: '.default_common .default_listView',
        userProps: {}
    };
    return $NewestBooksView$$NewestBooksList;
}((0, styling_context_1.styleableComponentMixin)(listview_1.default)));
var $NewestBooksView$$NewestBooksList$$LviBook = /** @class */ (function (_super) {
    __extends($NewestBooksView$$NewestBooksList$$LviBook, _super);
    function $NewestBooksView$$NewestBooksList$$LviBook(props) {
        return _super.call(this, props) || this;
    }
    $NewestBooksView$$NewestBooksList$$LviBook.$$styleContext = {
        classNames: '.sf-listViewItem .simple-listviewItem #mainPage-lviBook',
        defaultClassNames: '.default_common .default_listViewItem',
        userProps: { width: null, height: null }
    };
    return $NewestBooksView$$NewestBooksList$$LviBook;
}(LviBook_1.default));
//# sourceMappingURL=index.js.map