"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var $DetailsPage = /** @class */ (function (_super) {
    __extends($DetailsPage, _super);
    function $DetailsPage(props) {
        var _this = _super.call(this, Object.assign({ orientation: page_1.default.Orientation.PORTRAIT }, props)) || this;
        _this._children = {};
        _this.ios && (_this.ios.safeAreaLayoutMode = true);
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $BookInfo(), 'bookInfo');
        _this.addChildByName(new $Buttons(), 'buttons');
        _this.addChildByName(new $Button1(), 'button1');
        _this.bookInfo = _this.children.bookInfo;
        _this.image = _this.children.bookInfo.children.image;
        _this.title = _this.children.bookInfo.children.title;
        _this.author = _this.children.bookInfo.children.author;
        _this.point = _this.children.bookInfo.children.point;
        _this.description = _this.children.bookInfo.children.description;
        _this.buttons = _this.children.buttons;
        _this.button3 = _this.children.buttons.children.button3;
        _this.button2 = _this.children.buttons.children.button2;
        _this.button1 = _this.children.button1;
        _this.applyTestIDs('_DetailsPage');
        return _this;
    }
    Object.defineProperty($DetailsPage.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $DetailsPage.prototype.getName = function () {
        return 'DetailsPage';
    };
    $DetailsPage.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = ' ';
    };
    $DetailsPage.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $DetailsPage.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $DetailsPage.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $DetailsPage.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $DetailsPage.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $DetailsPage.$$styleContext = {
        classNames: '.sf-page #page2',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar #statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar #bookPage-header',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $DetailsPage;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $DetailsPage;
var $BookInfo = /** @class */ (function (_super) {
    __extends($BookInfo, _super);
    function $BookInfo(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $BookInfo$$Image(), 'image');
        _this.addChildByName(new $BookInfo$$Title(), 'title');
        _this.addChildByName(new $BookInfo$$Author(), 'author');
        _this.addChildByName(new $BookInfo$$Point(), 'point');
        _this.addChildByName(new $BookInfo$$Description(), 'description');
        return _this;
    }
    Object.defineProperty($BookInfo.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $BookInfo.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $BookInfo.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $BookInfo.$$styleContext = {
        classNames: '.sf-flexLayout #detailsPage-bookInfo',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $BookInfo;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $BookInfo$$Image = /** @class */ (function (_super) {
    __extends($BookInfo$$Image, _super);
    function $BookInfo$$Image(props) {
        return _super.call(this, props) || this;
    }
    $BookInfo$$Image.$$styleContext = {
        classNames: '.sf-imageView #bookPage-image',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $BookInfo$$Image;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $BookInfo$$Title = /** @class */ (function (_super) {
    __extends($BookInfo$$Title, _super);
    function $BookInfo$$Title(props) {
        return _super.call(this, { text: 'Book Title' }) || this;
    }
    $BookInfo$$Title.$$styleContext = {
        classNames: '.sf-label #bookPage-bookName',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $BookInfo$$Title;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $BookInfo$$Author = /** @class */ (function (_super) {
    __extends($BookInfo$$Author, _super);
    function $BookInfo$$Author(props) {
        return _super.call(this, { maxLines: 1, text: 'Author' }) || this;
    }
    $BookInfo$$Author.$$styleContext = {
        classNames: '.sf-label #bookPage-author',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $BookInfo$$Author;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $BookInfo$$Point = /** @class */ (function (_super) {
    __extends($BookInfo$$Point, _super);
    function $BookInfo$$Point(props) {
        return _super.call(this, { text: '4.5/5' }) || this;
    }
    $BookInfo$$Point.$$styleContext = {
        classNames: '.sf-label #bookPage-point',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $BookInfo$$Point;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $BookInfo$$Description = /** @class */ (function (_super) {
    __extends($BookInfo$$Description, _super);
    function $BookInfo$$Description(props) {
        return _super.call(this, {
            maxLines: 3,
            text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis semper justo. In ultrices metus nec sodales consectetur Aliquam erat volutpat. Suspendisse potenti.'
        }) || this;
    }
    $BookInfo$$Description.$$styleContext = {
        classNames: '.sf-label #detailsPage-description',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $BookInfo$$Description;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $Buttons = /** @class */ (function (_super) {
    __extends($Buttons, _super);
    function $Buttons(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $Buttons$$Button3(), 'button3');
        _this.addChildByName(new $Buttons$$Button2(), 'button2');
        return _this;
    }
    Object.defineProperty($Buttons.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $Buttons.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $Buttons.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Buttons.$$styleContext = {
        classNames: '.sf-flexLayout #detailsPage-buttons',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $Buttons;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $Buttons$$Button3 = /** @class */ (function (_super) {
    __extends($Buttons$$Button3, _super);
    function $Buttons$$Button3(props) {
        return _super.call(this, { text: ' PreView' }) || this;
    }
    $Buttons$$Button3.$$styleContext = {
        classNames: '.sf-button #bookPage-detailButtons',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $Buttons$$Button3;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $Buttons$$Button2 = /** @class */ (function (_super) {
    __extends($Buttons$$Button2, _super);
    function $Buttons$$Button2(props) {
        return _super.call(this, { text: ' ReViews' }) || this;
    }
    $Buttons$$Button2.$$styleContext = {
        classNames: '.sf-button #bookPage-detailButtons',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $Buttons$$Button2;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $Button1 = /** @class */ (function (_super) {
    __extends($Button1, _super);
    function $Button1(props) {
        return _super.call(this, { text: 'Buy Now for $46.99' }) || this;
    }
    $Button1.$$styleContext = {
        classNames: '.sf-button #detailsPage-purchaseButton',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $Button1;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=index.js.map