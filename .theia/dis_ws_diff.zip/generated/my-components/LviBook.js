"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var listviewitem_1 = __importDefault(require("@smartface/native/ui/listviewitem"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var $LviBook = /** @class */ (function (_super) {
    __extends($LviBook, _super);
    function $LviBook(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$ImageContainer(), 'imageContainer');
        _this.addChildByName(new $LviBook$$InfoContainer(), 'infoContainer');
        _this.imageContainer = _this.children.imageContainer;
        _this.image = _this.children.imageContainer.children.image;
        _this.infoContainer = _this.children.infoContainer;
        _this.titleContainer = _this.children.infoContainer.children.titleContainer;
        _this.title = _this.children.infoContainer.children.titleContainer.children.title;
        _this.authorContainer = _this.children.infoContainer.children.authorContainer;
        _this.author = _this.children.infoContainer.children.authorContainer.children.author;
        _this.pointContainer = _this.children.infoContainer.children.pointContainer;
        _this.point = _this.children.infoContainer.children.pointContainer.children.point;
        _this.testId = '___library___LviBook';
        return _this;
    }
    Object.defineProperty($LviBook.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $LviBook.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $LviBook.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook.$$styleContext = {
        classNames: '.sf-listViewItem .simple-listviewItem .lviBook',
        defaultClassNames: '.default_common .default_listViewItem',
        userProps: { width: null, height: null }
    };
    return $LviBook;
}((0, styling_context_1.styleableContainerComponentMixin)(listviewitem_1.default)));
exports.default = $LviBook;
var $LviBook$$ImageContainer = /** @class */ (function (_super) {
    __extends($LviBook$$ImageContainer, _super);
    function $LviBook$$ImageContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$ImageContainer$$Image(), 'image');
        _this.testId = '___library___LviBook_ImageContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$ImageContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$ImageContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$ImageContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$ImageContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainpage-bookList-imageView',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$ImageContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$ImageContainer$$Image = /** @class */ (function (_super) {
    __extends($LviBook$$ImageContainer$$Image, _super);
    function $LviBook$$ImageContainer$$Image(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___LviBook_ImageContainer_Image';
        return _this;
    }
    $LviBook$$ImageContainer$$Image.$$styleContext = {
        classNames: '.sf-imageView #mainPage-booList-image',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $LviBook$$ImageContainer$$Image;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $LviBook$$InfoContainer = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer, _super);
    function $LviBook$$InfoContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$InfoContainer$$TitleContainer(), 'titleContainer');
        _this.addChildByName(new $LviBook$$InfoContainer$$AuthorContainer(), 'authorContainer');
        _this.addChildByName(new $LviBook$$InfoContainer$$PointContainer(), 'pointContainer');
        _this.testId = '___library___LviBook_InfoContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$InfoContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$InfoContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$InfoContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$InfoContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-bookList-textView .lviBook-infoContainer',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$InfoContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$InfoContainer$$TitleContainer = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$TitleContainer, _super);
    function $LviBook$$InfoContainer$$TitleContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$InfoContainer$$TitleContainer$$Title(), 'title');
        _this.testId = '___library___LviBook_InfoContainer_TitleContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$InfoContainer$$TitleContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$InfoContainer$$TitleContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$InfoContainer$$TitleContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$InfoContainer$$TitleContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-bookList-bookTitle',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$TitleContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$InfoContainer$$TitleContainer$$Title = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$TitleContainer$$Title, _super);
    function $LviBook$$InfoContainer$$TitleContainer$$Title(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Title' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_TitleContainer_Title';
        return _this;
    }
    $LviBook$$InfoContainer$$TitleContainer$$Title.$$styleContext = {
        classNames: '.sf-label .boldText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$TitleContainer$$Title;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $LviBook$$InfoContainer$$AuthorContainer = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$AuthorContainer, _super);
    function $LviBook$$InfoContainer$$AuthorContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$InfoContainer$$AuthorContainer$$Author(), 'author');
        _this.testId = '___library___LviBook_InfoContainer_AuthorContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$InfoContainer$$AuthorContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$InfoContainer$$AuthorContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$InfoContainer$$AuthorContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$InfoContainer$$AuthorContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-bookList-bookAuthor',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$AuthorContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$InfoContainer$$AuthorContainer$$Author = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$AuthorContainer$$Author, _super);
    function $LviBook$$InfoContainer$$AuthorContainer$$Author(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Author' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_AuthorContainer_Author';
        return _this;
    }
    $LviBook$$InfoContainer$$AuthorContainer$$Author.$$styleContext = {
        classNames: '.sf-label .authorText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$AuthorContainer$$Author;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $LviBook$$InfoContainer$$PointContainer = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$PointContainer, _super);
    function $LviBook$$InfoContainer$$PointContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$InfoContainer$$PointContainer$$Point(), 'point');
        _this.testId = '___library___LviBook_InfoContainer_PointContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$InfoContainer$$PointContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$InfoContainer$$PointContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$InfoContainer$$PointContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$InfoContainer$$PointContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-bookList-point',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$PointContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$InfoContainer$$PointContainer$$Point = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$PointContainer$$Point, _super);
    function $LviBook$$InfoContainer$$PointContainer$$Point(props) {
        var _this = _super.call(this, { maxLines: 2, text: '4.5/5' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_PointContainer_Point';
        return _this;
    }
    $LviBook$$InfoContainer$$PointContainer$$Point.$$styleContext = {
        classNames: '.sf-label .pointText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$PointContainer$$Point;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
//# sourceMappingURL=LviBook.js.map