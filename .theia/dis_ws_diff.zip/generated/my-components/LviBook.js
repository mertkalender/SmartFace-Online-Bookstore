"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var listviewitem_1 = __importDefault(require("@smartface/native/ui/listviewitem"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var $LviBook = /** @class */ (function (_super) {
    __extends($LviBook, _super);
    function $LviBook(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$ImageContainer(), 'imageContainer');
        _this.addChildByName(new $LviBook$$InfoContainer(), 'infoContainer');
        _this.imageContainer = _this.children.imageContainer;
        _this.image = _this.children.imageContainer.children.image;
        _this.infoContainer = _this.children.infoContainer;
        _this.title = _this.children.infoContainer.children.title;
        _this.author = _this.children.infoContainer.children.author;
        _this.point = _this.children.infoContainer.children.point;
        _this.testId = '___library___LviBook';
        return _this;
    }
    Object.defineProperty($LviBook.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $LviBook.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $LviBook.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook.$$styleContext = {
        classNames: '.sf-listViewItem .simple-listviewItem .lviBook',
        defaultClassNames: '.default_common .default_listViewItem',
        userProps: { width: null, height: null }
    };
    return $LviBook;
}((0, styling_context_1.styleableContainerComponentMixin)(listviewitem_1.default)));
exports.default = $LviBook;
var $LviBook$$ImageContainer = /** @class */ (function (_super) {
    __extends($LviBook$$ImageContainer, _super);
    function $LviBook$$ImageContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$ImageContainer$$Image(), 'image');
        _this.testId = '___library___LviBook_ImageContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$ImageContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$ImageContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$ImageContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$ImageContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainpage-bookList-imageView',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$ImageContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$ImageContainer$$Image = /** @class */ (function (_super) {
    __extends($LviBook$$ImageContainer$$Image, _super);
    function $LviBook$$ImageContainer$$Image(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___LviBook_ImageContainer_Image';
        return _this;
    }
    $LviBook$$ImageContainer$$Image.$$styleContext = {
        classNames: '.sf-imageView #mainPage-booList-image',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $LviBook$$ImageContainer$$Image;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $LviBook$$InfoContainer = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer, _super);
    function $LviBook$$InfoContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $LviBook$$InfoContainer$$Title(), 'title');
        _this.addChildByName(new $LviBook$$InfoContainer$$Author(), 'author');
        _this.addChildByName(new $LviBook$$InfoContainer$$Point(), 'point');
        _this.testId = '___library___LviBook_InfoContainer';
        return _this;
    }
    Object.defineProperty($LviBook$$InfoContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $LviBook$$InfoContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $LviBook$$InfoContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $LviBook$$InfoContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-bookList-textView .lviBook-infoContainer',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $LviBook$$InfoContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $LviBook$$InfoContainer$$Title = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$Title, _super);
    function $LviBook$$InfoContainer$$Title(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Title' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_Title';
        return _this;
    }
    $LviBook$$InfoContainer$$Title.$$styleContext = {
        classNames: '.sf-label .boldText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$Title;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $LviBook$$InfoContainer$$Author = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$Author, _super);
    function $LviBook$$InfoContainer$$Author(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Author' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_Author';
        return _this;
    }
    $LviBook$$InfoContainer$$Author.$$styleContext = {
        classNames: '.sf-label .authorText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$Author;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $LviBook$$InfoContainer$$Point = /** @class */ (function (_super) {
    __extends($LviBook$$InfoContainer$$Point, _super);
    function $LviBook$$InfoContainer$$Point(props) {
        var _this = _super.call(this, { maxLines: 2, text: '4.5/5' }) || this;
        _this.testId = '___library___LviBook_InfoContainer_Point';
        return _this;
    }
    $LviBook$$InfoContainer$$Point.$$styleContext = {
        classNames: '.sf-label .pointText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LviBook$$InfoContainer$$Point;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
//# sourceMappingURL=LviBook.js.map