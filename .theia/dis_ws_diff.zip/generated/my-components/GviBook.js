"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var gridviewitem_1 = __importDefault(require("@smartface/native/ui/gridviewitem"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var imageview_1 = __importDefault(require("@smartface/native/ui/imageview"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var $GviBook = /** @class */ (function (_super) {
    __extends($GviBook, _super);
    function $GviBook(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $GviBook$$ImageContainer(), 'imageContainer');
        _this.addChildByName(new $GviBook$$InfoContainer(), 'infoContainer');
        _this.imageContainer = _this.children.imageContainer;
        _this.image = _this.children.imageContainer.children.image;
        _this.infoContainer = _this.children.infoContainer;
        _this.title = _this.children.infoContainer.children.title;
        _this.author = _this.children.infoContainer.children.author;
        _this.testId = '___library___GviBook';
        return _this;
    }
    Object.defineProperty($GviBook.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $GviBook.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $GviBook.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $GviBook.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $GviBook.$$styleContext = {
        classNames: '.sf-gridViewItem .simple-gridviewItem',
        defaultClassNames: '.default_common .default_gridViewItem',
        userProps: {}
    };
    return $GviBook;
}((0, styling_context_1.styleableContainerComponentMixin)(gridviewitem_1.default)));
exports.default = $GviBook;
var $GviBook$$ImageContainer = /** @class */ (function (_super) {
    __extends($GviBook$$ImageContainer, _super);
    function $GviBook$$ImageContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $GviBook$$ImageContainer$$Image(), 'image');
        _this.testId = '___library___GviBook_ImageContainer';
        return _this;
    }
    Object.defineProperty($GviBook$$ImageContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $GviBook$$ImageContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $GviBook$$ImageContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $GviBook$$ImageContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-gridView-ImageContainer',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $GviBook$$ImageContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $GviBook$$ImageContainer$$Image = /** @class */ (function (_super) {
    __extends($GviBook$$ImageContainer$$Image, _super);
    function $GviBook$$ImageContainer$$Image(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___GviBook_ImageContainer_Image';
        return _this;
    }
    $GviBook$$ImageContainer$$Image.$$styleContext = {
        classNames: '.sf-imageView #mainPage-gridView-image',
        defaultClassNames: '.default_common .default_imageView',
        userProps: {}
    };
    return $GviBook$$ImageContainer$$Image;
}((0, styling_context_1.styleableComponentMixin)(imageview_1.default)));
var $GviBook$$InfoContainer = /** @class */ (function (_super) {
    __extends($GviBook$$InfoContainer, _super);
    function $GviBook$$InfoContainer(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $GviBook$$InfoContainer$$Title(), 'title');
        _this.addChildByName(new $GviBook$$InfoContainer$$Author(), 'author');
        _this.testId = '___library___GviBook_InfoContainer';
        return _this;
    }
    Object.defineProperty($GviBook$$InfoContainer.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $GviBook$$InfoContainer.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $GviBook$$InfoContainer.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $GviBook$$InfoContainer.$$styleContext = {
        classNames: '.sf-flexLayout #mainPage-gridView-infoContainer',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $GviBook$$InfoContainer;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $GviBook$$InfoContainer$$Title = /** @class */ (function (_super) {
    __extends($GviBook$$InfoContainer$$Title, _super);
    function $GviBook$$InfoContainer$$Title(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Title' }) || this;
        _this.testId = '___library___GviBook_InfoContainer_Title';
        return _this;
    }
    $GviBook$$InfoContainer$$Title.$$styleContext = {
        classNames: '.sf-label .titleText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $GviBook$$InfoContainer$$Title;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $GviBook$$InfoContainer$$Author = /** @class */ (function (_super) {
    __extends($GviBook$$InfoContainer$$Author, _super);
    function $GviBook$$InfoContainer$$Author(props) {
        var _this = _super.call(this, { maxLines: 2, text: 'Book Author' }) || this;
        _this.testId = '___library___GviBook_InfoContainer_Author';
        return _this;
    }
    $GviBook$$InfoContainer$$Author.$$styleContext = {
        classNames: '.sf-label .authorText',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $GviBook$$InfoContainer$$Author;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
//# sourceMappingURL=GviBook.js.map