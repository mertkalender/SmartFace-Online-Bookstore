"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var detailsPage_1 = __importDefault(require("generated/pages/detailsPage"));
var headerbaritem_1 = __importDefault(require("@smartface/native/ui/headerbaritem"));
var mixins_1 = require("@smartface/mixins");
var color_1 = __importDefault(require("@smartface/native/ui/color"));
var i18n_1 = require("@smartface/i18n");
var styling_context_1 = require("@smartface/styling-context");
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var headerbaritem_2 = require("@smartface/native/ui/headerbaritem/headerbaritem");
var StyleableFlexLayout = /** @class */ (function (_super) {
    __extends(StyleableFlexLayout, _super);
    function StyleableFlexLayout() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return StyleableFlexLayout;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var detailsPage = /** @class */ (function (_super) {
    __extends(detailsPage, _super);
    function detailsPage(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.routeData = _this.route.getState().routeData;
        return _this;
    }
    detailsPage.prototype.languageTest = function () {
        console.log({
            helloWorld: i18n_1.i18n.instance.t('helloWorld'),
            welcomeUser: i18n_1.i18n.instance.t('welcomeUser', { user: 'Smartface' }),
            keyWithCount0: i18n_1.i18n.instance.t('keyWithCount', { count: 0 }),
            keyWithCount1: i18n_1.i18n.instance.t('keyWithCount', { count: 1 }),
            keyWithCount5: i18n_1.i18n.instance.t('keyWithCount', { count: 5 })
        });
    };
    /**
     * @event onShow
     * This event is called when a page appears on the screen (everytime).
     */
    detailsPage.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.headerBar.leftItemEnabled = false;
        this.headerBar.itemColor = color_1.default.BLACK;
        this.initBackButton(this.router);
        this.routeData && console.info(this.routeData.message);
    };
    /**
     * @event onLoad
     * This event is called once when page is created.
     */
    detailsPage.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.itemContainerFl = new StyleableFlexLayout();
        this.addChild(this.itemContainerFl, "itemContainerFl", '.sf-flexLayout', {
            height: 50,
            width: 50,
            flexProps: {
                justifyContent: 'CENTER',
                alignItems: 'CENTER'
            }
        });
        this.indicatorItem = new headerbaritem_1.default({
            customView: this.itemContainerFl
        });
        this.itemWithBadge = new headerbaritem_1.default({
            color: color_1.default.BLACK,
            android: {
                systemIcon: 17301545 // OR 'ic_dialog_email'
            },
            ios: {
                systemItem: headerbaritem_2.HeaderBarSystemItem.BOOKMARKS
            },
            onPress: function () {
            }
        });
        this.headerBar.setItems([this.itemWithBadge]);
        this.itemWithBadge.badge.visible = true;
        this.itemWithBadge.badge.text = '7';
        this.myItem = new headerbaritem_1.default({
            title: 'Done',
            onPress: function () {
                console.log('You pressed Done item!');
            }
        });
        this.headerBar.setItems([this.myItem]);
    };
    return detailsPage;
}((0, mixins_1.withDismissAndBackButton)(detailsPage_1.default)));
exports.default = detailsPage;
//# sourceMappingURL=detailsPage.js.map