"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.savedPage = exports.settingsPage = exports.cartPage = exports.detailsPage = exports.mainPage = void 0;
var mainPage_1 = require("./mainPage");
Object.defineProperty(exports, "mainPage", { enumerable: true, get: function () { return __importDefault(mainPage_1).default; } });
var detailsPage_1 = require("./detailsPage");
Object.defineProperty(exports, "detailsPage", { enumerable: true, get: function () { return __importDefault(detailsPage_1).default; } });
var cartPage_1 = require("./cartPage");
Object.defineProperty(exports, "cartPage", { enumerable: true, get: function () { return __importDefault(cartPage_1).default; } });
var settingsPage_1 = require("./settingsPage");
Object.defineProperty(exports, "settingsPage", { enumerable: true, get: function () { return __importDefault(settingsPage_1).default; } });
var savedPage_1 = require("./savedPage");
Object.defineProperty(exports, "savedPage", { enumerable: true, get: function () { return __importDefault(savedPage_1).default; } });
//# sourceMappingURL=index.js.map